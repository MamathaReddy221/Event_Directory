const jwt=require("jsonwebtoken");
const nodemailer=require("nodemailer")
const key="pavan"



 function generate(payload){
     console.log("my token "+payload)
    const token=jwt.sign(payload,key)
    return token
}

function verifying(token){
    try{
    const data=jwt.verify(token,key)
    return data
    }
    catch{
        return null
    }
}

const transporter=nodemailer.createTransport({
    service:"gmail",
    auth:{
        user:"k.mamatha9052@gmail.com",
        pass:"qswu nckm qhyh azoq"
    }
})
async function sendmail(to,event) {
    console.log(to)
     console.log(event)
  const mailOptions = {
    from: "k.mamatha9052@gmail.com",
    to,
    subject:"Events",
    text:`Register for event ${event}`
  };

  return transporter.sendMail(mailOptions);
}

 module.exports={generate,verifying,sendmail}
