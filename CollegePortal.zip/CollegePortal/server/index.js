const express=require('express')
const mongoose=require('mongoose')
const {route}=require('./routes/cp.js')
const cors=require('cors')

const app=express()
const port=8080

mongoose.connect("mongodb://127.0.0.1:27017/collegeportal")
.then(res=>console.log("connected to db"))
.catch(err=>console.log(err))

app.use(cors({
    origin:"*",
    credentials:true
}))

app.use(express.json())
app.use(express.urlencoded())
app.use('/api',route)

app.listen(port,()=>{
    console.log("hey")
})