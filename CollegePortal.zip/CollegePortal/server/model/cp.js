const mongoose=require('mongoose')

const userschema=mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true,
        unique:true
    },
    Designation:{
        type:String,
        required:true,
    } 
})

const clubschema=mongoose.Schema({
    clubname:{
        type:String,
        required:true
    },
    coordinatorId:{
        type:mongoose.Schema.ObjectId,
        reference:userschema
    },
    verified:{
        type:Boolean,
        default:false
    }
})

const eventschema=mongoose.Schema({
    eventname:{
        type:String,
        required:true
    },
    eventtime_date:{
        type:Date,
        required:true
    },
    eventvenue:{
        type:String,
        required:true
    },
    eventRegLink: {
    type: String,
    required: true,
    trim: true
    },
    eventclub:{
        type:mongoose.Schema.ObjectId,
        reference:clubschema
    }
})

const user=mongoose.model("user",userschema)
const club=mongoose.model("club",clubschema)
const event=mongoose.model("event",eventschema)


module.exports={event,club,user}