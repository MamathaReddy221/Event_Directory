//import multer from "multer";
const express=require('express')
const {home,signup,login,clubcreate,acceptance,getpendingclubs,
    eventcreation,eventdel,eventsget,clubrelevents, getusers,clubget}=require('../controller/cp.js')
const route=express.Router()

route.route('/').get(clubget)
route.route('/signup').post(signup)
route.route('/login').post(login)
route.route('/regclub').post(clubcreate)
route.route('/accept').post(acceptance)
route.route('/pending').get(getpendingclubs)
route.route('/eventcreate').post(eventcreation)
route.route('/events').get(eventsget)
route.route('/eventdel').delete(eventdel)
route.route('/clubrelevents').get(clubrelevents)
route.route('/getuser').get(getusers)
route.route('getClubs').get(clubget)




module.exports={route}
