const express=require('express')
const {user,club,event}=require('../model/cp.js')
const {generate,verifying,sendmail}=require('../service/cp.js')

async function home(req,res){
    console.log('home')
    return res.send('<h1>home<h1>')
}

async function signup(req,res){
    const data=req.body
    let f=false
    await user.create({name:data.name,email:data.email,password:data.password,Designation:data.designation})
    .then(res=>{f=true})
    .catch(err=>console.log(err))
    return res.json({msg:f?"success":"failed"})
}

async function login(req,res){
    console.log(req.body)
    const data=req.body
    let token
    await user.findOne({email:data.email,password:data.password})
    .then(re=>{
        
            if(re) {
                f=true;
                token=generate({email:data.email});
                console.log(token)
            }
            else f=false;
        })//if user is found we get their details in the res or we get null in res if user is not there
        .catch(err=>console.log(err))//this catch is to handle errors in query
        return res.json({message:f?"success":"failure",token:token});
    //return res.json({data:"Hello"})
}

async function clubcreate(req,res){
    const body=req.body
    const data=verifying(body.token)
    let userss;
    let f=false;
    if(data){
    await user.findOne({email:data.email,Designation:"cc"})
    .then(res=>userss=res)
    .catch(err=>console.log(err))
    await club.create({clubname:body.name,coordinatorId:userss._id})
    .then(res=>{f=true})
    .catch(err=>console.log(err))
    }
    return res.status(201).json({mesg:f?"success":"failed"})
}

async function acceptance(req,res){
    const body=req.body
    const email=verifying(body.token)
    let mc;
    await user.findOne({email:email.email,Designation:"mc"})
    .then(res=>mc=res)
    .catch(err=>console.log(err))
    if(mc){
    await club.updateOne({_id:body.clubid,verified:true})
    return res.status(201).json({msg:"success"})
    }
    return res.status(404).json({msg:"failed"})
}

async function getpendingclubs(req,res){//get method wont accept body sometimes so header is used.
    const token=req.get("Authorization")
    const email=verifying(token)
    let mc;
    let data;
    console.log(email)
    await user.findOne({email:email.email,Designation:"mc"})
    .then(res=>mc=res)
    .catch(err=>console.log(err))
    await club.find({verified:false})
    .then(res=>data=res)
    .catch(err=>console.log(err))
    console.log(data)
    return res.json({List:data})
}

async function eventcreation(req,res){
    const body=req.body
    const email=verifying(body.token)
    let f=false;
    let userss;
    await user.findOne({email:email.email,Designation:"cc"})
    .then(res=>userss=res)
    .catch(err=>console.log(err))
    let ccid;
    let events;
    if(userss){
        await club.findOne({coordinatorId:userss._id,verified:true})
        .then(res=>ccid=res._id)
        //.then(res=>console.log(res))
        .catch(err=>console.log(err))
        if(ccid){
    await event.create({
        eventname:body.name,
        eventtime_date:body.date,
        eventvenue:body.venue,
        eventRegLink:body.link,
        eventclub:ccid
    })
    .then(res=>events=res)
    .catch(err=>console.log(err))
    await userretrieve()
    .then(res=>{
        sendmail(res.join(", "),events.eventname)
        .then(res=>console.log(res))
        .catch(err=>console.log(err))
    })
        
}
}
    return res.status(201).json({msg:events?"success":"failed"})
} 

async function eventsget(req,res){
    const now=new Date()
    let data;
    await event.find({
        eventtime_date:{$gte:now},
    })
    .sort({eventtime_date :1})
    .then(res=>data=res)
    .catch(err=>console.log(err))
    return res.json({list:data})
}

async function clubget(req,res){
    let data=null;
    console.log("called")
    await club.find({verified:true})
    .then(res=>data=res)
    .catch(err=>console.log(err))
    console.log(data)
        return res.json({list:data})
}

async function clubrelevents(req,res){
    const token=req.get("Authorization")
    const email=verifying(token)
    let userss=null;
   let events=null;
    let clubs=null;
    
    await user.findOne({email:email.email,Designation:"cc"})
    .then(res=>userss=res)
    .catch(err=>console.log(err))
    if(userss){
    await club.findOne({coordinatorId:userss._id})
    .then(res=>clubs=res)
    .catch(err=>console.log)
    if(clubs){
    await event.find({eventclub:clubs._id})
    .then(res=>events=res)
    .catch(err=>console.log(err))

    }
}
    return res.json({list:events})
} 
async function eventdel(req,res){
    const body=req.body
    console.log(body)
    const e=verifying(req.get("Authorization"))
    let data;
    await user.findOne({email:e.email,Designation:"cc"})
    .then(res=>data=res)
    .catch(err=>console.log(err))
    let et;
    let d;
    if(data){
        await club.findOne({coordinatorId:data._id})
        .then(res=>et=res)
        .catch(err=>console.log(err))
        await event.deleteOne({eventclub:et._id,_id:body.id})
    .then(res=>d=res)
    .catch(err=>console.log(err))
    }
    return res.json({msg:d?"success":"failed"})
}
const userretrieve=async ()=>{
    let data;
    await  user.find({Designation:"gu"})
    .then(res=>
        data=res.map((d)=>
        d.email
))
    return data

}
async function getusers(req,res){
    const token=req.get("Authorization")
    const e=verifying(token);
    let userss;
    if(e){
            await user.findOne({email:e.email})
    .then(re=>userss=re)
    .catch(err=>console.log(err))
    return res.json({name:userss.name, Designation:userss.Designation})
    }
    return res.json({data:null})
}



module.exports={
    home,signup,login,clubcreate,acceptance,getpendingclubs,
    eventcreation,eventsget,clubget,eventdel,clubrelevents,userretrieve,getusers
}

