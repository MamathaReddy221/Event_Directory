//App.jsx

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Profile from './pages/Profile';
import Clubs from './pages/Clubs';
import { useState, useRef, useEffect } from 'react';
import axios from 'axios';


export default function App() {


  const [user, setUser] = useState(null);

    const getUser = async ()=>{
      let data = await axios.get('http://localhost:8080/api/getuser', {
            headers: { Authorization: localStorage.getItem('token') }
          })
      setUser(data.data)
      console.log(data.data)
      
    };

    useEffect(()=>{
      getUser();
    }, [])

  return (
      <BrowserRouter>
        <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
          <Navbar user={user} setUser={setUser}/>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login getUser={getUser}/>} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/clubs" element={<Clubs />} />
            <Route 
              path="/profile" 
              element={
                  <Profile user={user}/>
              } 
            />
          </Routes>
        </div>
      </BrowserRouter>
  );
}