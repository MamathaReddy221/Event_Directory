//Navbar.jsx

import { Link, useNavigate } from 'react-router-dom';


export default function Navbar(props) {
  const user = props.user
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.setItem('token', "")
    props.setUser(null)
    navigate('/login');
  };

  return (
    <nav className="bg-blue-600 text-white shadow-md">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold tracking-wide hover:text-blue-100">
          CampusPortal
        </Link>
        <div className="space-x-6 flex items-center">
          <Link to="/" className="hover:text-blue-200 transition">Events Feed</Link>
          <Link to="/clubs" className="hover:text-blue-200 transition">Clubs</Link>
          
          {user ? (
            <>
             {(user.Designation === 'cc'|| user.Designation==='mc' )&& <><Link to="/profile" className="hover:text-blue-200 transition font-semibold">
                  Dashboard
                </Link></>
             }
              
              <div className="flex items-center gap-4">
                <span className="text-sm bg-blue-700 px-3 py-1 rounded hidden md:block">
                  {user.name} ({user.Designation === 'cc' ? 'Coordinator' : user.Designation === 'mc'?"Main Coordinator":"Student"})
                </span>
                <button 
                  onClick={handleLogout} 
                  className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded transition shadow"
                >
                  Logout
                </button>
              </div>
            </>
          ) : (
            <>
              <Link to="/login" className="hover:text-blue-200 transition">Login</Link>
              <Link to="/signup" className="bg-white text-blue-600 px-4 py-2 rounded font-bold hover:bg-gray-100 transition">
                Sign Up
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}