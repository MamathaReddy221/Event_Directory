//Signup.jsx


import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Signup() {
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', designation: 'gu'
  });
  const navigate = useNavigate();

  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/api/signup', formData);
      alert("Registration Successful! Please Login.");
      navigate('/login');
    } catch (err) {
      alert("Signup Failed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-xl w-96">
        <h2 className="text-3xl font-bold mb-6 text-center text-blue-900">Create Account</h2>
        <form onSubmit={handleSignup} className="space-y-4">
          <input placeholder="Full Name" className="w-full border p-3 rounded" onChange={e => setFormData({...formData, name: e.target.value})} />
          <input placeholder="Email" className="w-full border p-3 rounded" onChange={e => setFormData({...formData, email: e.target.value})} />
          <input type="password" placeholder="Password" className="w-full border p-3 rounded" onChange={e => setFormData({...formData, password: e.target.value})} />
          
          <select className="w-full border p-3 rounded bg-white" onChange={e => setFormData({...formData, designation: e.target.value})}>
            <option value="gu">Student</option>
            <option value="cc">Club Coordinator</option>
          </select>
          <button className="w-full bg-green-600 text-white font-bold py-3 rounded hover:bg-green-700 transition">Register</button>
        </form>
      </div>
    </div>
  );
}