//Login.jsx

import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Login(props) {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      // 1. Get Token
      const data = await axios.post('http://localhost:8080/api/login', formData)
      console.log(data.data)
      localStorage.setItem('token', data.data.token);
      console.log(localStorage.getItem('token'))
      props.getUser();
      
      
      // 2. Pass token to Context (This triggers the user fetch)
      
      
      // 3. Navigate (The context will eventually update and redirect if needed, but we force it here for UX)
      // Since we don't know the role yet (it's async), we can send to Home or Profile.
      // A simple trick: send to home, and let them click dashboard, OR assume profile if valid.
      navigate('/'); 
      
    } catch (err) {
        alert("Invalid Credentials");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-xl w-96">
        <h2 className="text-3xl font-bold mb-6 text-center text-blue-900">Login</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <input 
            type="email" 
            placeholder="Email Address" 
            className="w-full border p-3 rounded"
            onChange={e => setFormData({...formData, email: e.target.value})}
          />
          <input 
            type="password" 
            placeholder="Password" 
            className="w-full border p-3 rounded"
            onChange={e => setFormData({...formData, password: e.target.value})}
          />
          <button className="w-full bg-blue-600 text-white font-bold py-3 rounded hover:bg-blue-700 transition">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}