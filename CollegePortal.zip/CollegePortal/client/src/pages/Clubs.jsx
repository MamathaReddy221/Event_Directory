import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Clubs() {
  const [clubs, setClubs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // API Call: Get All Verified Clubs
    axios.get('http://localhost:8080/api/')
      .then(res => {
        // Your controller returns: res.json({ list: data })
        // So we access res.data.list
        if (res.data.list && Array.isArray(res.data.list)) {
          setClubs(res.data.list);
        } else {
          setClubs([]);
        }
        setLoading(false);
      })
      .catch(err => {
        console.error("Failed to fetch clubs", err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="text-center mt-20 text-xl font-semibold text-blue-600">Loading Campus Clubs...</div>;

  return (
    <div className="container mx-auto px-6 py-10">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold text-blue-900 mb-4">Our Campus Clubs</h1>
        <p className="text-gray-600 text-lg">Explore the diverse communities driving innovation and fun on campus.</p>
      </div>

      {clubs.length === 0 ? (
        <div className="text-center bg-gray-50 p-10 rounded-lg">
            <p className="text-gray-500 text-lg">No active clubs found at the moment.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {clubs.map((club) => (
            <div key={club._id} className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition duration-300 transform hover:-translate-y-1 overflow-hidden border border-gray-100">
              
              {/* Card Header (Color Strip) */}
              <div className="h-3 bg-gradient-to-r from-blue-500 to-purple-600"></div>
              
              <div className="p-8">
                {/* Club Icon / Initials */}
                <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-6 text-2xl font-bold text-blue-600 mx-auto">
                  {club.clubname ? club.clubname.charAt(0).toUpperCase() : "C"}
                </div>

                <h2 className="text-2xl font-bold text-gray-800 text-center mb-3">
                  {club.clubname || "Unnamed Club"}
                </h2>
                
                <p className="text-gray-600 text-center mb-6 text-sm line-clamp-3">
                  {club.description || "Join us to learn, grow, and connect with like-minded students!"}
                </p>

                <div className="border-t pt-4">
                  <p className="text-sm text-gray-500 text-center mb-4">
                    <strong>Contact:</strong> {club.email}
                  </p>
                  
                  <button className="w-full py-2 px-4 bg-white border-2 border-blue-600 text-blue-600 font-bold rounded-lg hover:bg-blue-600 hover:text-white transition">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}