import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Profile(props) {
  // FIXED: Correct way to access user from props
  const { user } = props; 
  
  const [data, setData] = useState([]); // Stores Events (for CC) or Pending Clubs (for MC)
  const [newEvent, setNewEvent] = useState({ name: '', venue: '', date: '', link: '' });
  
  // State for creating a club (CC)
  const [newClub, setNewClub] = useState({ name: '', description: '' });
  
  const [activeTab, setActiveTab] = useState('list'); 
  
  const token = localStorage.getItem('token');
  const config = { headers: { Authorization: token } };
  // 1. Fetch Data based on Role
  useEffect(() => {
    if (user) {
      if (user.Designation === 'cc') { // user.designation (lowercase recommended)
        fetchEvents();
      } else if (user.Designation === 'mc') {
        fetchPendingClubs();
      }
    }
  }, [user]);

  // --- API CALLS ---

  const fetchEvents = () => {
    axios.get('http://localhost:8080/api/clubrelevents', config)
      .then(res => {console.log("My Events")
        setData(res.data.list);
        console.log(data);})
      .catch(err => console.error(err));
  };

  const fetchPendingClubs = () => {
    axios.get('http://localhost:8080/api/pending', config)
    .then(
      res =>{
        console.log(res)
        setData(res)
       }
      )
    .catch(err => console.error(err));
    
  };

  // --- HANDLERS FOR CC (Events & Club Creation) ---

  const handleCreateEvent = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/api/eventcreate', newEvent, config);
      alert("Event Published!");
      setNewEvent({ name: '', venue: '', date: '', link: '', token:token });
      setActiveTab('list');
      fetchEvents();
    } catch (err) {
      alert("Error creating event.");
    }
  };

  const handleDeleteEvent = async (id) => {
    if(!window.confirm("Delete this event?")) return;
    try {
      await axios.delete('http://localhost:8080/api/eventdel', { 
        headers: { Authorization: token },
        data: { id , token} 
      });
      // Update UI locally
      setData(data.filter(item => item._id !== id));
    } catch (err) {
      alert("Failed to delete");
    }
  };

  // New: CC creates a Club
  const handleCreateClub = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/api/regclub', newClub, config);
      alert("Club Registered Successfully!");
      setNewClub({ name: '', description: '' });
      setActiveTab('list'); 
    } catch (err) {
      alert("Failed to register club.");
    }
  };

  // --- HANDLERS FOR MC (Approvals) ---

  const handleAcceptClub = async (id) => {
    try {
      // Calling the acceptance API
      // Note: Assuming the API expects { id: ... } in the body. 
      await axios.post('http://localhost:8080/api/accept', { id: id, token:token }, config);
      alert("Club Approved!");
      fetchPendingClubs(); // Refresh list to remove the accepted club
    } catch (err) {
      console.error(err);
      alert("Error approving club.");
    }
  };

  // Safety check if user is not loaded yet
  if (!user) return <div className="p-10 text-center">Loading Profile...</div>;

  return (
    <div className="container mx-auto px-6 py-10">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 border-b pb-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">
            {user.designation === 'mc' ? "Main Coordinator Dashboard" : "Club Coordinator Dashboard"}
          </h1>
          <p className="text-blue-600 font-semibold mt-1">
            Welcome, {user.name}
          </p>
        </div>
        
        {/* BUTTONS: Render different buttons based on role */}
        <div className="space-x-4 mt-4 md:mt-0">
          
          {/* CC Buttons */}
          {user.Designation === 'cc' && (
            <>
              <button 
                onClick={() => setActiveTab('list')}
                className={`px-4 py-2 rounded ${activeTab === 'list' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
              >
                My Events
              </button>
              <button 
                onClick={() => setActiveTab('create_event')}
                className={`px-4 py-2 rounded ${activeTab === 'create_event' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
              >
                Add Event
              </button>
              <button 
                onClick={() => setActiveTab('create_club')}
                className={`px-4 py-2 rounded ${activeTab === 'create_club' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
              >
                Register Club
              </button>
            </>
          )}

          {/* MC Buttons */}
          {user.Designation === 'mc' && (
             <button 
                className="px-4 py-2 rounded bg-blue-600 text-white cursor-default"
             >
               Pending Approvals
             </button>
          )}
        </div>
      </div>

      {/* --- CONTENT AREA: MAIN COORDINATOR (MC) --- */}
      {user.Designation === 'mc' && (
        <div className="space-y-4">
           <h2 className="text-xl font-bold mb-4">Pending Club Requests</h2>
           {data.length === 0 && <p className="text-gray-500">No pending requests.</p>}
           {data.map((club) => (
             <div key={club._id} className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg shadow flex justify-between items-center">
               <div>
                 <h3 className="text-xl font-bold text-gray-800">{club.name || "Club Request"}</h3>
                 {/* If your pending API returns club description or details, show them here */}
               </div>
               <button 
                 onClick={() => handleAcceptClub(club._id)}
                 className="bg-green-600 text-white px-6 py-2 rounded font-bold hover:bg-green-700 shadow transition"
               >
                 Accept
               </button>
             </div>
           ))}
           
        </div>
      )}

      {/* --- CONTENT AREA: CLUB COORDINATOR (CC) --- */}
      
      {/* 1. List Events */}
      {user.Designation === 'cc' && activeTab === 'list' && (
        <div className="space-y-4">
          {data.length === 0 && <p className="text-gray-500 text-center py-10">No events posted yet.</p>}
          {data.map((item) => (
            <div key={item._id} className="bg-white p-6 rounded-lg shadow flex justify-between items-center hover:bg-gray-50 transition border-l-4 border-blue-500">
              <div>
                <h3 className="text-xl font-bold text-gray-800">{item.eventname}</h3>
                <p className="text-gray-600">Venue: {item.eventtime_date} | Date: {new Date(item.eventtime_date).toDateString()}</p>
                <a href={item.eventRegLink} >Click To Register</a>
              </div>
              <button 
                onClick={() => handleDeleteEvent(item._id)}
                className="bg-red-100 text-red-600 px-4 py-2 rounded font-semibold hover:bg-red-200 transition"
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 2. Create Event Form */}
      {user.Designation === 'cc' && activeTab === 'create_event' && (
        <div className="max-w-xl mx-auto bg-white p-8 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold mb-6">Create New Event</h2>
          <form onSubmit={handleCreateEvent} className="space-y-4">
            <input required placeholder="Event Name" className="w-full border p-3 rounded" value={newEvent.name} onChange={e => setNewEvent({...newEvent, name: e.target.value})} />
            <input required placeholder="Venue" className="w-full border p-3 rounded" value={newEvent.venue} onChange={e => setNewEvent({...newEvent, venue: e.target.value})} />
            <input required type="date" className="w-full border p-3 rounded" value={newEvent.date} onChange={e => setNewEvent({...newEvent, date: e.target.value})} />
            <input required placeholder="Registration Link" className="w-full border p-3 rounded" value={newEvent.link} onChange={e => setNewEvent({...newEvent, link: e.target.value, token:token})} />
            <button className="w-full bg-green-600 text-white py-3 rounded font-bold hover:bg-green-700">Publish Event</button>
          </form>
        </div>
      )}

      {/* 3. Create Club Form (New Feature) */}
      {user.Designation === 'cc' && activeTab === 'create_club' && (
        <div className="max-w-xl mx-auto bg-white p-8 rounded-lg shadow-lg border-t-4 border-purple-500">
          <h2 className="text-2xl font-bold mb-6 text-purple-900">Register Your Club</h2>
          <form onSubmit={handleCreateClub} className="space-y-4">
            <input 
              required 
              placeholder="Club Name" 
              className="w-full border p-3 rounded focus:ring-2 focus:ring-purple-500 outline-none" 
              value={newClub.name} 
              onChange={e => setNewClub({...newClub, name: e.target.value})} 
            />
            <textarea 
              required 
              placeholder="Club Description" 
              className="w-full border p-3 rounded h-32 focus:ring-2 focus:ring-purple-500 outline-none" 
              value={newClub.description} 
              onChange={e => setNewClub({...newClub, description: e.target.value, token:token})} 
            />
            <button className="w-full bg-purple-600 text-white py-3 rounded font-bold hover:bg-purple-700 transition">
              Submit for Approval
            </button>
          </form>
        </div>
      )}

    </div>
  );
}