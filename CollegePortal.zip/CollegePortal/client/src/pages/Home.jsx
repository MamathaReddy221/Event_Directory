//Home.jsx

import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // API Call: Public Events Feed
    axios.get('http://localhost:8080/api/events')
      .then(res => {
        console.log(res.data.list)
        setEvents(res.data.list);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="text-center mt-20 text-xl">Loading events...</div>;
 
  return (
    <div className="container mx-auto px-6 py-10">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold text-blue-900 mb-4">Upcoming Campus Events</h1>
        <p className="text-gray-600 text-lg">Discover what's happening in your college clubs.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {(events && events.length === 0) ?(
        <p className="text-center text-gray-500 mt-10">No upcoming events found.</p>
      ):
        events.map((event) => (
          <div key={event._id} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition duration-300 border border-gray-100">
            <div className="bg-blue-600 h-2 w-full"></div>
            <div className="p-6">
              <span className="text-xs font-bold text-blue-500 uppercase tracking-wider">{event.clubName}</span>
              <h2 className="text-2xl font-bold text-gray-800 mt-2 mb-2">{event.eventname}</h2>
              
              <div className="text-gray-600 space-y-1 mb-6">
                <p className="flex items-center"><span className="font-semibold w-16">Venue:</span> {event.eventvenue}</p>
                <p className="flex items-center"><span className="font-semibold w-16">Date:</span> {new Date(event.eventtime_date).toDateString()}</p>
              </div>

              <a 
                href={event.eventRegLink} 
                target="_blank" 
                rel="noreferrer"
                className="block w-full text-center bg-blue-100 text-blue-700 font-semibold py-2 rounded hover:bg-blue-200 transition"
              >
                Register Now
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
